<?php
    if($_FILES){
        if($_FILES['file']['size'] >= (2 * 1024 * 1024)){
            echo 'File size exceeds 2MB limit.';
        } else {
            if(getimagesize($_FILES['file']['tmp_name'])){
                $uploardDir = 'uploads/';
                $fileName = basename($_FILES['file']['name']);
                move_uploaded_file($_FILES['file']['tmp_name'], $uploardDir . $fileName);
                echo 'File uploaded successfully: ' . $fileName;
                echo '<br>';
                echo '<img src="' . $uploardDir . $fileName . '" alt="Uploaded Image" style="max-width: 300px; max-height: 300px;">';

            } else {
                echo 'File is not a valid image.';
            }
        }
    } else {
        echo "No file uploaded.";
    }
?>