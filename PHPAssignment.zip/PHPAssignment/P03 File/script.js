document.getElementById('file').addEventListener('change', function(e) {
    const fileName = e.target.files[0]?.name;
    const label = document.querySelector('.file-input-label');
    if (fileName) {
        label.textContent = `📄 ${fileName}`;
        label.style.color = '#28a745';
        label.style.borderColor = '#28a745';
    }
});
