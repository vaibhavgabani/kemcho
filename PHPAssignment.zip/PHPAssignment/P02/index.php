<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="post">
        <div>
            <label>Rollno</label>
            <input type="text" name="rollno" id="" value="<?php echo isset($_SESSION['rollno']) ? $_SESSION['rollno'] : ''; ?>">
        </div>
        <div>
            <label>Name</label>
            <input type="text" name="name" id="" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>">
        </div>
        <div>
            <label>Date of Birth</label>
            <input type="date" name="dob" id="" value="<?php echo isset($_SESSION['dob']) ? $_SESSION['dob'] : ''; ?>">
        <div>
            <input type="submit" value="Submit" name="submit">
        </div>
    </form>
    <form action="page2.php">
        <input type="submit" value="Next">
    </form>
    <?php
    if ($_REQUEST) {
        print_r($_REQUEST);
        $_SESSION["rollno"] = $_POST["rollno"];
        $_SESSION["name"] = $_POST["name"];
        $_SESSION["dob"] = $_POST["dob"];
    }
    ?>
</body>

</html>