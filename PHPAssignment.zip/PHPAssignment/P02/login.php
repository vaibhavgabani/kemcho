    <?php
    session_start();
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>

    <body>
        <form action="dashbord.php" method="post">
            <input type="number" name="rollno" value="<?php echo isset($_COOKIE['rollno']) ? $_COOKIE['rollno'] : ''; ?>"><br>
            <input type="text" name="name" value="<?php echo isset($_COOKIE['name']) ? $_COOKIE['name'] : ''; ?>"><br>
            <input type="checkbox" name="remember" id="">Remember Me
            <br>
            <input name="submit" type="submit" value="Submit">
        </form>
    </body>

    <?php
    if (isset($_POST['submit'])) {
        if (isset($_POST['remember'])) {
            setcookie("name", $_POST['name']);
            setcookie("rollno", $_POST['rollno']);
        } else {
            setcookie("name", "");
            setcookie("rollno", "");
        }
        header("Location: dashbord.php");
        exit();
    }
    ?>
    </html>