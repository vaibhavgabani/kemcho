<?php
    session_start();
    if ($_REQUEST) {
        print_r($_REQUEST);
        $_SESSION["email"] = $_POST["email"];
        $_SESSION["phonenumber"] = $_POST["phonenumber"];
        $_SESSION["address"] = $_POST["address"];

        header("Location: final.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="post">
        <div>
            <label>Email</label>
            <input type="email" name="email" id="" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : '';?>">
        </div>
        <div>
            <label>Phone Number</label>
            <input type="number" name="phonenumber" id="" value="<?php echo isset($_SESSION['phonenumber']) ? $_SESSION['phonenumber'] : '';?>">
        </div>
        <div>
            <label>Address</label>
            <input type="text" name="address" id="" value="<?php echo isset($_SESSION['address']) ? $_SESSION['address'] : '';?>">
        </div>
        <div>
            <input type="submit" value="Submit">
        </div>
    </form>
    <br>
    <form action="page2.php">
        <input type="submit" value="Previus">
    </form>
</body>

</html>