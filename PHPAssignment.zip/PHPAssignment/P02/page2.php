<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="post">
        <div>
            <label>Course</label>
            <input type="text" name="course" id="" value="<?php echo isset($_SESSION['course']) ? $_SESSION['course'] : ''; ?>" >
        </div>
        <div>
            <label>Semester</label>
            <input type="number" name="semester" id="" value="<?php echo isset($_SESSION['semester']) ? $_SESSION['semester'] : ''; ?>">
        </div>
        <div>
            <label>Percentage</label>
            <input type="number" name="percentage" id="" value="<?php echo isset($_SESSION['percentage']) ? $_SESSION['percentage'] : ''; ?>">
        </div>
        <div>
            <input type="submit" value="Submit">
        </div>
    </form>
    <form action="index.php">
        <input type="submit" value="Previus">
    </form>
    <form action="page3.php">   
        <input type="submit" value="Next">
    </form>
    <?php
    if ($_REQUEST) {
        print_r($_REQUEST);
        $_SESSION["course"] = $_POST["course"];
        $_SESSION["semester"] = $_POST["semester"];
        $_SESSION["percentage"] = $_POST["percentage"];
    }
    ?>
</body>

</html>